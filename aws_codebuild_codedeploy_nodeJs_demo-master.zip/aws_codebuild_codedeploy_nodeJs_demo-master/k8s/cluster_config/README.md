To add cluster use:

eksctl create cluster -f cluster.yaml


to delete:

eksctl delete cluster -f cluster.yaml
